package py.edu.uc.lp32025.interfaces;

import py.edu.uc.lp32025.exception.DiasInsuficientesException;
import java.time.LocalDate;

public interface PermisionableGerente {

    /**
     * Vacaciones para gerentes, con máximo 30 días consecutivos.
     * ✅ CAMBIO: Lanza DiasInsuficientesException (compatible con Permisionable)
     */
    void solicitarVacaciones(LocalDate inicio, LocalDate fin)
            throws DiasInsuficientesException;

    /**
     * Permisos especiales para gerentes, máximo 10 días.
     * ✅ CAMBIO: Lanza DiasInsuficientesException (compatible con Permisionable)
     */
    void solicitarPermiso(String motivo, LocalDate inicio, LocalDate fin)
            throws DiasInsuficientesException;

    /**
     * Cálculo de bono anual exclusivo de gerentes.
     */
    java.math.BigDecimal calcularBonoAnual();
}
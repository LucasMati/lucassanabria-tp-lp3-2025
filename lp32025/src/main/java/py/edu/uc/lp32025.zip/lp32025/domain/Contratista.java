package py.edu.uc.lp32025.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import py.edu.uc.lp32025.exception.DiasInsuficientesException;
import py.edu.uc.lp32025.interfaces.Permisionable;
import lombok.extern.slf4j.Slf4j;

@Entity
@Slf4j
public class Contratista extends Persona implements Permisionable {

    @Column(nullable = false)
    private BigDecimal montoPorProyecto;

    @Column(nullable = false)
    private Integer proyectosCompletados;

    @Column(nullable = false)
    private LocalDate fechaFinContrato;

    private static final int LIMITE_DIAS_ANUALES = 20;

    // =============================================================
    // Getters y Setters
    // =============================================================

    public BigDecimal getMontoPorProyecto() {
        return montoPorProyecto;
    }

    public void setMontoPorProyecto(BigDecimal montoPorProyecto) {
        this.montoPorProyecto = montoPorProyecto;
    }

    public Integer getProyectosCompletados() {
        return proyectosCompletados;
    }

    public void setProyectosCompletados(Integer proyectosCompletados) {
        this.proyectosCompletados = proyectosCompletados;
    }

    public LocalDate getFechaFinContrato() {
        return fechaFinContrato;
    }

    public void setFechaFinContrato(LocalDate fechaFinContrato) {
        this.fechaFinContrato = fechaFinContrato;
    }

    // =============================================================
    // Métodos sobrescritos
    // =============================================================

    /**
     * Salario = montoPorProyecto × proyectosCompletados
     */
    @Override
    public BigDecimal calcularSalario() {
        if (montoPorProyecto == null || proyectosCompletados == null) return BigDecimal.ZERO;
        return montoPorProyecto.multiply(BigDecimal.valueOf(proyectosCompletados));
    }

    /**
     * Deducciones = 0 (sin deducciones)
     */
    @Override
    public BigDecimal calcularDeducciones() {
        return BigDecimal.ZERO;
    }

    /**
     * Validación: fecha futura, proyectos ≥ 0, monto > 0
     */
    @Override
    public boolean validarDatosEspecificos() {
        return fechaFinContrato != null
                && fechaFinContrato.isAfter(LocalDate.now())
                && proyectosCompletados != null
                && proyectosCompletados >= 0
                && montoPorProyecto != null
                && montoPorProyecto.compareTo(BigDecimal.ZERO) > 0;
    }

    // =============================================================
    // Método adicional: contratoVigente
    // =============================================================

    public boolean contratoVigente() {
        return fechaFinContrato != null && !fechaFinContrato.isBefore(LocalDate.now());
    }

    // =============================================================
    // IMPLEMENTACIÓN DE PERMISIONABLE - LÍMITE 20 DÍAS/AÑO
    // =============================================================

    @Override
    public void solicitarVacaciones(LocalDate inicio, LocalDate fin) throws DiasInsuficientesException {
        long diasSolicitados = ChronoUnit.DAYS.between(inicio, fin);
        int totalActual = getDiasVacacionesAnuales() + getDiasPermisoAnuales();
        int diasDisponibles = LIMITE_DIAS_ANUALES - totalActual;

        // Validar que no supere el límite de 20 días anuales
        if (totalActual + diasSolicitados > LIMITE_DIAS_ANUALES) {
            throw new DiasInsuficientesException(
                    "Vacaciones rechazadas: supera el límite anual de " + LIMITE_DIAS_ANUALES + " días. " +
                            "Ya tiene " + totalActual + " días solicitados y quiere agregar " + diasSolicitados + " más.",
                    (int) diasSolicitados,
                    diasDisponibles,
                    inicio,
                    fin
            );
        }

        setDiasVacacionesAnuales(getDiasVacacionesAnuales() + (int) diasSolicitados);

        log.info("✅ Vacaciones aprobadas para {}: {} días (Total anual: {}/{})",
                getNombre(), diasSolicitados, getTotalDiasSolicitados(), LIMITE_DIAS_ANUALES);
    }

    @Override
    public void solicitarPermiso(String motivo, LocalDate inicio, LocalDate fin) throws DiasInsuficientesException {
        long diasSolicitados = ChronoUnit.DAYS.between(inicio, fin);
        int totalActual = getDiasVacacionesAnuales() + getDiasPermisoAnuales();
        int diasDisponibles = LIMITE_DIAS_ANUALES - totalActual;

        // Validar que no supere el límite de 20 días anuales
        if (totalActual + diasSolicitados > LIMITE_DIAS_ANUALES) {
            throw new DiasInsuficientesException(
                    "Permiso rechazado: supera el límite anual de " + LIMITE_DIAS_ANUALES + " días. " +
                            "Ya tiene " + totalActual + " días solicitados y quiere agregar " + diasSolicitados + " más.",
                    (int) diasSolicitados,
                    diasDisponibles,
                    inicio,
                    fin
            );
        }

        setDiasPermisoAnuales(getDiasPermisoAnuales() + (int) diasSolicitados);

        log.info("✅ Permiso aprobado para {}: {} días (Motivo: {}, Total anual: {}/{})",
                getNombre(), diasSolicitados, motivo, getTotalDiasSolicitados(), LIMITE_DIAS_ANUALES);
    }

    // =============================================================
    // Información extendida para el reporte
    // =============================================================

    @Override
    public String obtenerInformacionCompleta() {
        return super.obtenerInformacionCompleta() +
                ", Fecha fin contrato: " + fechaFinContrato +
                ", Contrato vigente: " + contratoVigente() +
                ", Días solicitados: " + getTotalDiasSolicitados() + "/" + LIMITE_DIAS_ANUALES;
    }
}